# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Nurlan-Aliev/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Nurlan-Aliev/python-project-lvl1/actions)\n\n<a href="https://codeclimate.com/github/Nurlan-Aliev/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/f787b300615a3ec8be61/maintainability" /></a>\n\n\nbrain-even: Установка, запуск игры. Демонстрация игры с победой и поражением https://asciinema.org/a/lCaiqVyA4RdZTaVodSb2uhV6l\n\nbrain-calc. Демонстрация игры с победой и поражением. https://asciinema.org/a/vSO1eGTM9hhd9TjqilWP5bk7R\n\nbrain-gcd.  Демонстрация игры с победой и поражением. https://asciinema.org/a/g1yS9HrrutlZznKS5k3kr5Tqr\n\nbrain-progression. Демонстрация игры с победой и поражением. https://asciinema.org/a/JR9YWSzkEDqQAByf7V8HeF4Q3\n',
    'author': 'Aliev Nurlan',
    'author_email': 'nualiev420@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
