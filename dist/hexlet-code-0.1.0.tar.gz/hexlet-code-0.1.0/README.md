### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nurlan-Aliev/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Nurlan-Aliev/python-project-lvl1/actions)

<a href="https://codeclimate.com/github/Nurlan-Aliev/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/f787b300615a3ec8be61/maintainability" /></a>


Установка, запуск игры brain-even. Пример с успешным прохождением игры и поражением https://asciinema.org/a/lCaiqVyA4RdZTaVodSb2uhV6l

Демонстрация игры с победой и поражением brain-calc. https://asciinema.org/a/vSO1eGTM9hhd9TjqilWP5bk7R

Демонстрация игры с победой и поражением brain-gcd. https://asciinema.org/a/g1yS9HrrutlZznKS5k3kr5Tqr
