### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nurlan-Aliev/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Nurlan-Aliev/python-project-lvl1/actions)

<a href="https://codeclimate.com/github/Nurlan-Aliev/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/f787b300615a3ec8be61/maintainability" /></a>


brain-even: Установка, запуск игры. Демонстрация игры с победой и поражением https://asciinema.org/a/lCaiqVyA4RdZTaVodSb2uhV6l

brain-calc. Демонстрация игры с победой и поражением. https://asciinema.org/a/vSO1eGTM9hhd9TjqilWP5bk7R

brain-gcd.  Демонстрация игры с победой и поражением. https://asciinema.org/a/g1yS9HrrutlZznKS5k3kr5Tqr

brain-progression. Демонстрация игры с победой и поражением. https://asciinema.org/a/JR9YWSzkEDqQAByf7V8HeF4Q3
